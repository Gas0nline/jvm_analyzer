package com.example.jvmlab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JvmLabApplication {
    public static void main(String[] args) {
        SpringApplication.run(JvmLabApplication.class, args);
    }
}
