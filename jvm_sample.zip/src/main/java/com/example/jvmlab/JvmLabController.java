package com.example.jvmlab;

import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

@RestController
@RequestMapping("/load")
public class JvmLabController {

    private final List<byte[]> leakedObjects = new ArrayList<>();
    private final List<Thread> spawnedThreads = new CopyOnWriteArrayList<>();
    private final AtomicLong cpuRuns = new AtomicLong();
    private final AtomicBoolean deadlockStarted = new AtomicBoolean(false);

    private final Object lockA = new Object();
    private final Object lockB = new Object();

    /**
     * CPU-intensive workload.
     * Example: curl "localhost:8080/load/cpu?seconds=30&threads=2"
     */
    @GetMapping("/cpu")
    public Map<String, Object> cpu(
            @RequestParam(defaultValue = "20") int seconds,
            @RequestParam(defaultValue = "1") int threads) {

        seconds = Math.max(1, Math.min(seconds, 300));
        threads = Math.max(1, Math.min(threads, 64));

        long runId = cpuRuns.incrementAndGet();
        long durationNanos = TimeUnit.SECONDS.toNanos(seconds);
        ExecutorService executor = Executors.newFixedThreadPool(threads);

        for (int i = 0; i < threads; i++) {
            final int worker = i;
            executor.submit(() -> {
                long end = System.nanoTime() + durationNanos;
                double x = worker + 0.123;
                while (System.nanoTime() < end) {
                    x = Math.sin(x) * Math.cos(x) + Math.sqrt(Math.abs(x) + 1.0);
                }
                return x;
            });
        }

        executor.shutdown();

        return Map.of(
                "scenario", "cpu",
                "runId", runId,
                "seconds", seconds,
                "threads", threads,
                "message", "CPU workload started"
        );
    }

    /**
     * Temporary memory pressure.
     * Example: curl "localhost:8080/load/memory?mb=256&duration=60"
     */
    @GetMapping("/memory")
    public Map<String, Object> memory(
            @RequestParam(defaultValue = "256") int mb,
            @RequestParam(defaultValue = "60") int duration) throws InterruptedException {

        mb = Math.max(1, Math.min(mb, 2048));
        duration = Math.max(1, Math.min(duration, 600));

        List<byte[]> allocations = new ArrayList<>();
        for (int i = 0; i < mb; i++) {
            byte[] block = new byte[1024 * 1024];
            Arrays.fill(block, (byte) 1);
            allocations.add(block);
        }

        Thread.sleep(duration * 1000L);

        return Map.of(
                "scenario", "memory",
                "allocatedMB", mb,
                "durationSeconds", duration,
                "message", "Temporary allocations completed"
        );
    }

    /**
     * Intentional memory leak.
     * Example: curl "localhost:8080/load/leak?mb=50"
     */
    @GetMapping("/leak")
    public synchronized Map<String, Object> leak(
            @RequestParam(defaultValue = "50") int mb) {

        mb = Math.max(1, Math.min(mb, 1024));

        for (int i = 0; i < mb; i++) {
            byte[] block = new byte[1024 * 1024];
            Arrays.fill(block, (byte) 7);
            leakedObjects.add(block);
        }

        return Map.of(
                "scenario", "leak",
                "addedMB", mb,
                "retainedObjects", leakedObjects.size(),
                "estimatedRetainedMB", leakedObjects.size(),
                "message", "Objects are intentionally retained"
        );
    }

    @PostMapping("/leak/reset")
    public synchronized Map<String, Object> resetLeak() {
        int previous = leakedObjects.size();
        leakedObjects.clear();
        System.gc();

        return Map.of(
                "scenario", "leak-reset",
                "releasedApproxMB", previous,
                "message", "References cleared; GC requested"
        );
    }

    /**
     * Creates many sleeping threads.
     * Example: curl "localhost:8080/load/threads?count=500"
     */
    @GetMapping("/threads")
    public synchronized Map<String, Object> threads(
            @RequestParam(defaultValue = "100") int count) {

        count = Math.max(1, Math.min(count, 2000));

        int created = 0;
        for (int i = 0; i < count; i++) {
            Thread t = new Thread(() -> {
                try {
                    Thread.sleep(TimeUnit.HOURS.toMillis(1));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }, "jvm-lab-worker-" + spawnedThreads.size());

            t.start();
            spawnedThreads.add(t);
            created++;
        }

        return Map.of(
                "scenario", "threads",
                "created", created,
                "totalTracked", spawnedThreads.size(),
                "message", "Sleeping threads created"
        );
    }

    @PostMapping("/threads/reset")
    public synchronized Map<String, Object> resetThreads() {
        int interrupted = 0;
        for (Thread t : spawnedThreads) {
            if (t.isAlive()) {
                t.interrupt();
                interrupted++;
            }
        }
        spawnedThreads.clear();

        return Map.of(
                "scenario", "threads-reset",
                "interrupted", interrupted
        );
    }

    /**
     * Deliberate deadlock.
     * Example: curl -X POST localhost:8080/load/deadlock
     */
    @PostMapping("/deadlock")
    public Map<String, Object> deadlock() {
        if (!deadlockStarted.compareAndSet(false, true)) {
            return Map.of("scenario", "deadlock", "message", "Already started");
        }

        Thread t1 = new Thread(() -> {
            synchronized (lockA) {
                sleep(500);
                synchronized (lockB) {
                    // Never reached
                }
            }
        }, "jvm-lab-deadlock-A");

        Thread t2 = new Thread(() -> {
            synchronized (lockB) {
                sleep(500);
                synchronized (lockA) {
                    // Never reached
                }
            }
        }, "jvm-lab-deadlock-B");

        t1.start();
        t2.start();

        return Map.of(
                "scenario", "deadlock",
                "message", "Two threads were started and should deadlock"
        );
    }

    /**
     * Allocation storm for GC analysis.
     * Example: curl "localhost:8080/load/gc?seconds=30"
     */
    @GetMapping("/gc")
    public Map<String, Object> gc(
            @RequestParam(defaultValue = "30") int seconds) {

        seconds = Math.max(1, Math.min(seconds, 300));

        final int duration = seconds;
        Thread t = new Thread(() -> {
            long end = System.nanoTime() + TimeUnit.SECONDS.toNanos(duration);
            while (System.nanoTime() < end) {
                for (int i = 0; i < 10_000; i++) {
                    byte[] garbage = new byte[1024 + (i % 4096)];
                    garbage[0] = (byte) i;
                }
            }
        }, "jvm-lab-gc-allocator");

        t.start();

        return Map.of(
                "scenario", "gc",
                "seconds", seconds,
                "message", "Allocation storm started"
        );
    }

    @GetMapping("/status")
    public Map<String, Object> status() {
        return Map.of(
                "leakedObjects", leakedObjects.size(),
                "trackedThreads", spawnedThreads.size(),
                "cpuRuns", cpuRuns.get(),
                "deadlockStarted", deadlockStarted.get()
        );
    }

    private static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
