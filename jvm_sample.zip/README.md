# JVM Lab — Spring Boot

Petite application Spring Boot volontairement conçue pour provoquer des symptômes JVM et pratiquer leur analyse.

## Prérequis

- Java 21
- Maven 3.9+
- Docker + Docker Compose (optionnel)

## Lancer en local

```bash
mvn spring-boot:run
```

Ou :

```bash
mvn clean package
java \
  -Xms256m \
  -Xmx768m \
  -XX:+UseG1GC \
  -XX:+HeapDumpOnOutOfMemoryError \
  -XX:HeapDumpPath=./dumps \
  -Xlog:gc*,safepoint:file=./dumps/gc.log:time,uptime,level,tags:filecount=5,filesize=20M \
  -jar target/jvm-lab-1.0.0.jar
```

Application : http://localhost:8080

Actuator : http://localhost:8080/actuator

Prometheus : http://localhost:8080/actuator/prometheus

## Scénarios

### 1. CPU

```bash
curl "http://localhost:8080/load/cpu?seconds=60&threads=4"
```

Analyse :

```bash
jps -lv
top -H -p <PID>
jcmd <PID> Thread.print
jstack <PID>
```

Objectif : identifier les threads consommant du CPU et retrouver leur stack.

### 2. Pression mémoire temporaire

```bash
curl "http://localhost:8080/load/memory?mb=400&duration=60"
```

Analyse :

```bash
jstat -gc <PID> 1000
jcmd <PID> GC.heap_info
jcmd <PID> GC.class_histogram
```

Objectif : observer allocation rate et activité GC.

### 3. Fuite mémoire

```bash
curl "http://localhost:8080/load/leak?mb=100"
```

Répéter plusieurs fois.

```bash
jcmd <PID> GC.heap_info
jcmd <PID> GC.class_histogram
```

Puis :

```bash
jcmd <PID> GC.heap_dump ./dumps/heap.hprof
```

Objectif : distinguer forte allocation et rétention d'objets.

Réinitialisation :

```bash
curl -X POST http://localhost:8080/load/leak/reset
```

### 4. Explosion du nombre de threads

```bash
curl "http://localhost:8080/load/threads?count=500"
```

Analyse :

```bash
ps -eLf | grep java | wc -l
top -H -p <PID>
jcmd <PID> Thread.print
```

Reset :

```bash
curl -X POST http://localhost:8080/load/threads/reset
```

### 5. Deadlock

```bash
curl -X POST http://localhost:8080/load/deadlock
```

Puis :

```bash
jcmd <PID> Thread.print
```

La sortie doit signaler les threads bloqués et le deadlock.

### 6. Allocation storm / GC

```bash
curl "http://localhost:8080/load/gc?seconds=120"
```

Analyse :

```bash
jstat -gcutil <PID> 1000
jcmd <PID> GC.heap_info
tail -f ./dumps/gc.log
```

Objectif : observer les collections et leur fréquence.

## Actuator

Quelques endpoints utiles :

```bash
curl http://localhost:8080/actuator/health
curl http://localhost:8080/actuator/metrics
curl http://localhost:8080/actuator/metrics/jvm.memory.used
curl http://localhost:8080/actuator/metrics/jvm.gc.pause
curl http://localhost:8080/actuator/metrics/jvm.threads.live
curl http://localhost:8080/actuator/prometheus
```

## Docker + Prometheus + Grafana

```bash
mvn clean package
docker compose up --build
```

Puis :

- Application : http://localhost:8080
- Prometheus : http://localhost:9090
- Grafana : http://localhost:3000

Dans Grafana, ajouter Prometheus comme datasource avec :

```text
http://prometheus:9090
```

## JFR

Avec une JVM locale :

```bash
jcmd <PID> JFR.start name=jvm-lab settings=profile duration=2m filename=./dumps/jvm-lab.jfr
```

Ou démarrage manuel :

```bash
jcmd <PID> JFR.start name=analysis settings=profile
```

Puis :

```bash
jcmd <PID> JFR.dump name=analysis filename=./dumps/analysis.jfr
jcmd <PID> JFR.stop name=analysis
```

Ouvrir le fichier `.jfr` avec Java Mission Control.

## Parcours conseillé

1. CPU
2. Threads
3. Deadlock
4. GC
5. Memory pressure
6. Leak
7. Heap dump
8. JFR
9. Prometheus/Grafana

Le but est de commencer avec uniquement les symptômes système, puis de descendre progressivement dans la JVM.
